<?php

namespace App\Http\Controllers;

use App\Models\Members;
use Illuminate\Http\Request;

class MembersController extends Controller
{
    public function index()
    {
        $members = Members::select('school', 'college', 'yearlevel','program','major', 'acceptdate', )
            ->selectRaw("CONCAT(firstname, ' ', midinitial, ' ', lastname) as Fullname")
            ->orderBy('membersID')->get();

        return view('members', compact('members'));
    }
}
