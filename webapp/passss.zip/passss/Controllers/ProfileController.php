<?php

namespace App\Http\Controllers;
use App\Models\Members;

use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function showProfile()
    {
        $membersModel = new Members();
        $members = $membersModel->getAllMembers();

        return view('profile', compact('members'));
    }
    public function editProfile()
    {
        return view('profile-edit');
    }

    public function deleteProfile()
    {
        return view('profile-delete');
    }
}
