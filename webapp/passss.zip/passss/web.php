<?php

use App\Http\Controllers\UserController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RequirementsController;
use App\Http\Controllers\MembersController;
use App\Http\Controllers\GradesController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/members', [MembersController::class, 'showMembers']);
Route::get('/members-add', [MembersController::class, 'addMembers']);
Route::get('/profile', [ProfileController::class, 'showProfile']);
Route::get('/reqs-page', [RequirementsController::class, 'showRequirements']);
Route::get('/grades-page', [GradesController::class, 'showGrades']);

Route::get('/', function () {
    return view('grades-page');
});

// Route::get('/', [MembersController::class, 'index']);
// Route::get('/welcome', [MembersController::class, 'show']);


// Route::get('/', [StudentController::class, 'index']);


// Route::get('/users', [UserController::class, 'index']) -> name('login');

// Route::get('/user/{id}', [UserController::class, 'show']);
// Route::get('/students', [StudentController::class, 'index']);


