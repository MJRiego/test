<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class members extends Model
{
    use HasFactory;
    protected $table = 'members';
    public function getAllMembers()
    {
        return $this->select('batchnum','school', 'college', 'yearlevel', 'program', 'major', 'acceptdate', 'age','sex','birthdate','civilstatus','religion','mobile','email', 'address')
            ->selectRaw("CONCAT(firstname, ' ', midinitial, ' ', lastname) as Fullname")
            ->orderBy('memberID')
            ->get();
    }
}

